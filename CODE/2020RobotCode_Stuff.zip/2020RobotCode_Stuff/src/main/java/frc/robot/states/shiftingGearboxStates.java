package frc.robot.states;

public enum shiftingGearboxStates{
    IN, OUT
    //IN = faster speed; lower gear ratio
    //OUT = lower speed; higher gear ratio
}
